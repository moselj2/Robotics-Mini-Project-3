bug_path: modified bug from start to qf
bug_path100: finds paths to 100 points (run after point_generator)
NH_Drive: Non-holonomic planner (run after PRM_path or RRT_path)
point_generator: generates 100 random points in the free space
PotField_path: finds path to qf with potential field method
PotField_path100: Finds paths to 100 points (run after point_generator)
PRM_path: finds path to qf with probability roadmap
PRM_path_100: finds paths to 100 points (run after point_generator)
RRT_path: finds path to qf with rapidly-expanding random tree
RRT_path_100: finds paths to 100 points (run after point generator)
