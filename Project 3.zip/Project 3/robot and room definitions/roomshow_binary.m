colobj = roomspec();

resolution = 100;
binary_map = color2binary(colobj, resolution);

%show(binary_map);
%view(-90,90);

inflate(binary_map,0.2);
show(binary_map);
view(-90,90);
