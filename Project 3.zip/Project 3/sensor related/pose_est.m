%
% pose_est.m
%
% Given y and robot kinematics, estimate the robot position and orientation
%
function qhat=pose_est(y,pL,pB,N_scan,wcov,vcov)

% use range sensors first
N_range=size(pL,2);N_bearing=size(pB,2);N_odo=2;

pRest=[];

% use two range sensors intersecting with the x-y plane
ez=[0;0;1];
ind=nchoosek(1:N_range,2);
zz=two_range_sensor_and_plane(pL(:,ind(1,1)),pL(:,ind(1,2)), y(ind(1,1)),y(ind(1,2)),ez,zeros(3,1));
[minval,j]=min(vecnorm(zz(1:2,1:2)));
z1(:,1)=zz(:,j);

indnan=find(isnan(z1));z1(indnan)=[];z1=reshape(z1,3,length(z1)/3);
if ~isempty(z1)
    pRest=z1;
end
% use two bearing sensors and a range sensor

for i=1:N_range 
    [zz,qq]=two_bearing_one_range(pB,pL(:,i), y(N_range+N_odo+1:N_range+N_odo+2),y(i));
    [minval,j]=min(vecnorm(zz(1:2,1:2)-pRest(1:2,1)));
    z2(:,i)=zz(:,j);
    q2(:,i)=qq(j);
end
indnan=find(isnan(z2));z2(indnan)=[];z2=reshape(z2,3,length(z2)/3);
indnan=find(isnan(q2));q2(indnan)=[];
qRest3=mean(q2);
if size(z2,2)>1
  pRest3=mean(z2(1:2,:)')';
else
  pRest3=z2(1:2,:);
end

qhat=[pRest(1:2);qRest3];

end