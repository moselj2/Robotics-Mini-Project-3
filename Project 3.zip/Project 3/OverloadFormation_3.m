clear all; close all;

% FOR THIS CODE: input 3

 graphsel=input(['enter 1 for fully connected \n',...
    '2 for unidirectionally connected (A)\n',...
    '3 for unidirectionally connected (B)\n']);

 switch graphsel
    case 1
        % 4 agents fully connected
        n1=[];n2=[];
                for i=1:4
                    n1=[n1 i*ones(1,4-i)];
                    n2=[n2 (i+1:4)];
                end
        % generate graph using node pairs
        G=graph(n1,n2);
        % generate the non-sparse incidence matrix from the graph
        D=full(incidence(G));
        dz=[3 sqrt(3) 3 3 sqrt(3) 3]
    case 2
        n1=[2 3 4 2 4]; n2=[1 1 1 3 3];
        % generate graph using node pairs
        G=digraph(n1,n2);
        % generate the non-sparse incidence matrix from the graph
        D=full(incidence(G));
     case 3
        n1=[2 3 4 2 4 4]; n2=[1 1 1 3 3 2];
        % generate graph using node pairs
        G=digraph(n1,n2);
        % generate the non-sparse incidence matrix from the graph
        D=full(incidence(G));
        dz= [2 2 2.8 2 2.8 2 2];
 end

 D
% show the graph connection of agents
figure(20);plot(G);
set(gcf,'position',[100,400,500,500]);
% # of links
l = size(D,2);
% # of states for each agent
n = 2;
% center for formation
c = [0;0];
% # of time steps
N = 20;
% # of agents
p = size(D,1);
% allocate space
q = zeros(n*p,2*N+1);
u = zeros(n*p,2*N);
z = zeros(n*l,2*N+1);
% initial condition
%q(:,1) = rand(n*p,1);
q(:,1)=[1;1;1;-1;-1;-1;-1;1];
z(:,1) = kron(D',eye(n,n))*q(:,1);
% distance from center
dc = .2;
% distance from each other
%dz = dc*2*pi/p*ones(l,1);
%dz = 2*ones(l,1);
% time step
ts = 1;
% time vector
t = (0:3*N)*ts;
% feedback gain
%Kp = .1*eye(n*p,n*p);
Kp = 0.1*eye(n*p,n*p);
Kp1 = 0.1*eye(n*p,n*p);
% define the potential function
%s = @(x,d) (1/d - 1/x);
s = @(x,d) log(x/d);
%s = @(x,d) max(min(log(1/(x-d)^2),1),-1); %bad, wrong signs
%s = @(x,d) max(min(log(x/d)*(1+abs(x-d))^2,0.75),-0.75);
%s = @(x,d)  log(x/d)*(1+abs(x-d));

% control loop
for k=1:N
    % link difference vectors z = D^T * q 
    zk = kron(D',eye(n,n))*q(:,k);
    % for each link compute the potential gradient
    for j=1:l
        zkj = zk((j-1)*n+1:j*n);        
        psi((j-1)*n+1:j*n,1) = s(norm(zkj),dz(j))*zkj/norm(zkj);
    end
    % potential gradient to the origin
    for i=1:p
        qki = q((i-1)*n+1:i*n,k);
        phi((i-1)*n+1:i*n,1) = s(norm(qki-c),dc)*(qki-c)/norm(qki-c);
    end

    % controller combines the two
    u(:,k) = -Kp*kron(D,eye(n,n))*psi - Kp1 * phi;
    q(:,k+1) = q(:,k)+ts*u(:,k);
    z(:,k+1) = kron(D',eye(n,n))*q(:,k+1);
end
[G,D,dz]=rotationA(G,D);
% control loop
for k=N+1:2*N
    % link difference vectors z = D^T * q 
    zk = kron(D',eye(n,n))*q(:,k);
    % for each link compute the potential gradient
    for j=1:l
        zkj = zk((j-1)*n+1:j*n);        
        psi((j-1)*n+1:j*n,1) = s(norm(zkj),dz(j))*zkj/norm(zkj);
    end
    % potential gradient to the origin
    for i=1:p
        qki = q((i-1)*n+1:i*n,k);
        phi((i-1)*n+1:i*n,1) = s(norm(qki-c),dc)*(qki-c)/norm(qki-c);
    end
    % controller combines the two
    u(:,k) = -Kp*kron(D,eye(n,n))*psi - Kp1 * phi;
    q(:,k+1) = q(:,k)+ts*u(:,k);
    z(:,k+1) = kron(D',eye(n,n))*q(:,k+1);
end
[G,D,dz]=rotationB(G,D);
% control loop
for k=2*N+1:3*N
    % link difference vectors z = D^T * q 
    zk = kron(D',eye(n,n))*q(:,k);
    % for each link compute the potential gradient
    for j=1:l
        zkj = zk((j-1)*n+1:j*n);        
        psi((j-1)*n+1:j*n,1) = s(norm(zkj),dz(j))*zkj/norm(zkj);
    end
    % potential gradient to the origin
    for i=1:p
        qki = q((i-1)*n+1:i*n,k);
        phi((i-1)*n+1:i*n,1) = s(norm(qki-c),dc)*(qki-c)/norm(qki-c);
    end
    % controller combines the two
    u(:,k) = -Kp*kron(D,eye(n,n))*psi - Kp1 * phi;
    q(:,k+1) = q(:,k)+ts*u(:,k);
    z(:,k+1) = kron(D',eye(n,n))*q(:,k+1);
end


figure(10);hold on
for i=1:l
    zvec{i}(:,:)=z((i-1)*n+1:i*n,:);
    plot(t,vecnorm(zvec{i})-dz(i));
end
hold off

zf = kron(D',eye(n,n))*q(:,2*N+1);
disp('final z distance');
disp(vecnorm(reshape(zf,n,l)))
% qf= reshape(q(:,N+1),n,p);
% disp('final distance from c');
% disp(vecnorm(qf-c));
% hold off

figure(2);
for k=1:3*N+1
    qk=q(:,k);
    qkflat=reshape(qk,n,p);
    plot(qkflat(1,1),qkflat(2,1),'o','linewidth',3); hold on;
    plot(qkflat(1,2),qkflat(2,2),'o','linewidth',3); hold on;
    plot(qkflat(1,3),qkflat(2,3),'o','linewidth',3); hold on;
    plot(qkflat(1,4),qkflat(2,4),'o','linewidth',3); hold off;
    legend('1','2','3','4');
    axis([-4,4,-4,4]);axis('square');
    M(k)=getframe;
end
movie(M);

function [G,D,dz]=rotationA(G,D)
    n1=[2 3 4 2 4 4]; n2=[1 1 1 3 3 2]; %same as above
    %n1=[2 3 4 2 4 4]; n2=[1 1 1 3 3 2];  %switching nodes 3 and 4
    %dz= [3 3 3 sqrt(18) 3 sqrt(18) 3 sqrt(18)];
    % generate graph using node pairs
    G=digraph(n1,n2);
    % generate the non-sparse incidence matrix from the graph
    D=full(incidence(G))
    dz= [1.5 1 1 2 2 0.1];
    % show the graph connection of agents
    figure(20);plot(G);
    set(gcf,'position',[100,400,500,500]);
end

function [G,D,dz]=rotationB(G,D)
    %n1=[2 3 4 3 3 2 1 1]; n2=[1 1 1 2 4 4 4 3]; %same as above
    n1=[2 3 4 2 4 4]; n2=[1 1 1 3 3 2];  %switching nodes 3 and 4
    %dz= [3 3 3 sqrt(18) 3 sqrt(18) 3 sqrt(18)];
    % generate graph using node pairs
    G=digraph(n1,n2);
    % generate the non-sparse incidence matrix from the graph
    D=full(incidence(G))
    %dz= [1 6 1 1 1 1];
    dz= [2 2.8 2 2.8 2 2];
    % show the graph connection of agents
    figure(20);plot(G);
    set(gcf,'position',[100,400,500,500]);
end
