clear all; close all;

p=4;
% p agents fully connected
n1=[];n2=[];
for i=1:p
    n1=[n1 i*ones(1,p-i)];
    n2=[n2 (i+1:p)];
end
% generate graph using node pairs
G=graph(n1,n2);
% generate the non-sparse incidence matrix from the graph
D=full(incidence(G));

% # of links
l = size(D,2);
% # of states for each agent
n = 2;
% center for formation
c = [0;0];
% # of time steps
N = 100;
% # of agents
p = size(D,1);
% allocate space
q = zeros(n*p,N+1);
u = zeros(n*p,N);
z = zeros(n*l,N+1);
% initial condition
q(:,1) = rand(n*p,1);
z(:,1) = kron(D',eye(n,n))*q(:,1);
% distance from center
dc = .2;
% distance from each other
%dz = [2;2;2];
dz = dc*2*pi/p*ones(l,1);
dz = 2*ones(l,1);
% time step
ts = 1;
% time vector
t = (0:N)*ts;
% feedback gain
Kp = 0.1*eye(n*p,n*p);
Kp1 = 0.3*eye(n*p,n*p);
% define the potential function
%s = @(x,d) (1/d - 1/x);
s = @(x,d) log(x/d);

% set up key press detection in figure
%qkflat=reshape(q(:,1),n,p);
%plot(qkflat(1,:),qkflat(2,:),'^','linewidth',3);
%h_fig=plot(qkflat(1,:),qkflat(2,:),'^','linewidth',3);
%set(h_fig,'KeyPressFcn',@robotfcn);
keyvalue='a';
keypressed=0;
k=1;
% control loop
while keyvalue~='q'
    w = waitforbuttonpress;
    if w
       keyvalue = get(gcf, 'CurrentCharacter'); 
    end
    switch keyvalue %w,a,s,d to move & r to rotate
        case 119 %w
            c=c+[0;0.1];
        case 115 %s
            c=c+[0;-0.1];
        case 97 %a
            c=c+[-0.1;0];
        case 100 %d
            c=c+[0.1;0];
        case 114 %r
            c=c+[0;0];
        case 48
            c=c+[0;0];
    end
    % link difference vectors z = D^T * q 
    zk = kron(D',eye(n,n))*q(:,k);
    % for each link compute the potential gradient
    for j=1:l
        zkj = zk((j-1)*n+1:j*n);        
        psi((j-1)*n+1:j*n,1) = s(norm(zkj),dz(j))*zkj/norm(zkj);
    end
    % potential gradient to the origin
    for i=1:p
        qki = q((i-1)*n+1:i*n,k);
        phi((i-1)*n+1:i*n,1) = s(norm(qki-c),dc)*(qki-c)/norm(qki-c);
    end
    % controller combines the two
    phi2=[];
    if keyvalue==114
        for i=1:4
            v=qkflat(:,i)-c;
            theta = pi/6;
            R = [cosd(theta) -sind(theta); sind(theta) cosd(theta)];
            vR = (v'*R)';
            %phi=[vR;zeros(6,1)];
            phi2=[phi2 ;vR-v];
        end
        %phi=[qkflat(:,1);qkflat(:,2);qkflat(:,3);qkflat(:,4)]-phi;
        phi=phi+50*phi2;
    end
    u(:,k) = -Kp*kron(D,eye(n,n))*psi - Kp1 * phi;
    q(:,k+1) = q(:,k)+ts*u(:,k);
    z(:,k+1) = kron(D',eye(n,n))*q(:,k+1);
    qkflat=reshape(q(:,k+1),n,p);
    plot(qkflat(1,:),qkflat(2,:),'^','linewidth',3);
    axis([c(1)-4,c(1)+4,c(2)-4,c(2)+4]);axis('square');
    xlabel('X [meters]'); ylabel('Y [meters]');
    M(k)=getframe;
    k=k+1;
end

movie(M);
