function y=testfcn(x)

y=[sin(3*x(1)+4*x(2)+7*x(3));-cos(5*x(2)+3*x(3)-4)];

end